import tkinter
import tkinter.messagebox
import pynput
import time
import threading
from tkinter import *
gbs = '`'
list=['`','a','b','c','d','e','f','g','h','i','j','k','l','-','=']
number=0
class Mouseclick:
    def __init__(self, button, time):
        self.mouse = pynput.mouse.Controller()
        self.running = False  # 确认是否在运行
        self.time = time
        self.close = False
        self.button = button
        # 开启主监听线程
        self.listener = pynput.keyboard.Listener(on_press=self.key_press)
        self.listener.start()
 
    def key_press(self, key):
        try:
            if key.char == gbs:
                if self.running == False:
                    self.running = True
                    # 停止连点也需要调用这个函数
                    self.mouse_click()
                else:
                    self.running = False
                    self.mouse_click()
        except:
            pass
    def mouse_click(self):
        # 这里还需要额外线程进行监听，为了能够更新self.running，防止陷入死循环
        key_listener = pynput.keyboard.Listener(on_press=self.key_press)
        key_listener.start()
        while self.running and not(self.close):
            self.mouse.click(self.button)
            time.sleep(float(self.time))
        key_listener.stop()
    def pop(self):
        self.close=True
        self.listener.stop()
mousec = None
hh=True
# 新线程处理函数
def new_thread_start(button, time):
    global mousec
    # 例化类
    if mousec != None:
        mousec.pop()
        del mousec
    mousec = Mouseclick(button,time)
def key_press(key):
    global gbs,label1
    try:
        gbs=key.char
        label1['text'] = '当前开关键为：' + gbs
    except:
        pass
def on_closing():
    global gg,hh
    key_listener.stop() #停止键盘监听
    gg.destroy() #关闭窗口
    hh=True #设置可以打开新的改变开关键窗口
def abc():
    global gbs,list,number
    if number<len(list)-1:
        number+=1
        gbs=list[number]
    else:
        number=0
        gbs=list[number]
    label1['text'] = '当前开关键为：' + gbs
#选择连点开始关闭键
def gb():
    global gg,key_listener,hh,label1
    if hh:#检测是否可以打开改变开关键窗口
        #hh=False#设置不可以新的改变开关键窗口
        gg = tkinter.Tk()  # 新的tk界面
        gg.title('改变连点开关键(为键盘)')
        gg.geometry('300x200')
        gg.resizable(0, 0)
        label1 = tkinter.Button(gg,text='当前开关键为：' + gbs, font=("微软雅黑", 11), fg="gray",command=abc)
        label1.place(relx=0.27,rely=0.3)
        key_listener = pynput.keyboard.Listener(on_press=key_press)
        key_listener.start()
        gg.protocol("WM_DELETE_WINDOW", on_closing) #关闭窗口时执行on_closing函数
        gg.mainloop()
# START按键处理函数
def start():
    try:
        # 将文本框读到的字符串转化为浮点数
        time = float(input.get())
        if mouse.get() == 0:
            button = pynput.mouse.Button.left
        elif mouse.get() == 1:
            button = pynput.mouse.Button.right
        # 开启新线程，避免GUI卡死
        t = threading.Thread(target=new_thread_start, args=(button, time))
        # 开启守护线程，这样在GUI意外关闭时线程能正常退出
        #t.setDaemon(True)
        t.start()
        # 不能使用 t.join()，否则也会卡死
    except:
        tkinter.messagebox.showerror(title='报错',message='输入错误')
def close():
    if not(hh): #关闭窗口时检测gg是否打开
        gg.destroy() #关闭gg窗口
    root.destroy() #关闭root窗口
def stop():
    global mousec
    if mousec != None:
        mousec.pop()
        del mousec
        mousec=None
    tkinter.messagebox.showinfo('提示','成功结束')
#图形界面
root = Tk()
root.title('WSL鼠标连点器')
root.geometry('600x290')
 
mouse = IntVar()
lab1 = Label(root, text='点击类型', font=("微软雅黑", 11), fg="gray")
lab1.place(relx=0.05, y=10, relwidth=0.4, height=30)
r1 = Radiobutton(root, text='鼠标左键', font=("微软雅黑", 10), value=0, variable=mouse)
r1.place(relx=0.05, y=40, relwidth=0.17, height=30)
r2 = Radiobutton(root, text='鼠标右键', font=("微软雅黑", 10), value=1, variable=mouse)
r2.place(relx=0.2, y=40, relwidth=0.3, height=30)
 
lab2 = Label(root, text='点击间隔时间', font=("微软雅黑", 11), fg="gray")
lab2.place(relx=0.55, y=10, relwidth=0.4, height=30)
input = Entry(root, font=("微软雅黑", 10))
input.place(relx=0.55, y=40, relwidth=0.4, height=30)
 
 
btn_start = Button(root, text='改变开关连点键', font=("微软雅黑", 12), fg="white", bg="gray", command=gb)
btn_start.place(relx=0.3, y=170, relwidth=0.4, height=30)
btn_start1 = Button(root, text='更新', font=("微软雅黑", 12), fg="white", bg="gray", command=start)
btn_start1.place(relx=0.3, y=240, relwidth=0.4, height=30)
btn_start2 = Button(root, text='结束', font=("微软雅黑", 12), fg="white", bg="gray", command=stop)
btn_start2.place(relx=0.3, y=100, relwidth=0.4, height=30)
root.protocol("WM_DELETE_WINDOW", close)#关闭root窗口时执行close函数
root.mainloop()
