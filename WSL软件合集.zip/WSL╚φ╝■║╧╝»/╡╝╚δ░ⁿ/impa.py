import tkinter
import tkinter as tk
import tkinter.filedialog
import tkinter.messagebox
import tkinter.scrolledtext
import tkinter.colorchooser
import tkinter.simpledialog
import tkinter
import tkinter.messagebox
import threading
import idlelib.colorizer as idc
import idlelib.percolator as idp
from tkinter import *
from tkinter.scrolledtext import ScrolledText
from tkinter import messagebox
from threading import Thread
from tkinter.ttk import *
import tkinter
import tkinter as tk
import tkinter.filedialog
import tkinter.messagebox
import tkinter.scrolledtext
import tkinter.colorchooser
import tkinter.simpledialog
import tkinter
import tkinter.messagebox
import threading
from tkinter import *
from tkinter.scrolledtext import ScrolledText
from tkinter import messagebox
from threading import Thread
from tkinter.ttk import *
import win32con
import win32api
import time
import pykeyboard
k=pykeyboard.PyKeyboard()
key_map = {
    "0": 49, "1": 50, "2": 51, "3": 52, "4": 53, "5": 54, "6": 55, "7": 56, "8": 57, "9": 58,
    "A": 65, "B": 66, "C": 67, "D": 68, "E": 69, "F": 70, "G": 71, "H": 72, "I": 73, "J": 74,
    "K": 75, "L": 76, "M": 77, "N": 78, "O": 79, "P": 80, "Q": 81, "R": 82, "S": 83, "T": 84,
    "U": 85, "V": 86, "W": 87, "X": 88, "Y": 89, "Z": 90
}
def progress_bar(name='进度条',times_=None):
    """进度条"""

    import PySimpleGUI as sg
    import time
    import random

    num=1000

    # 布局，是一个用户定义的二维列表。
    # 第一维德元素分居不同的行上,第二维度上的元素们居于同一行,不同列上
    # 此处定义的列表  由三部分组成 Text文件 ProgressBar进度条 Cancel取消按钮构成
    # Text Progress等有各自的参数设置，如size等。此处不再赘述
    layout = [[sg.Text('进度:')],
              [sg.ProgressBar(num, orientation='h', size=(20, 20), key='progressbar')],
              [sg.Cancel()]]

    # window只需将自定义的布局加载出来即可 第一个参数是窗口标题。
    window = sg.Window(name, layout)

    # 根据key值获取到进度条
    progress_bar = window['progressbar']

    # window的read函数分为同步和异步，
    # 不带timeout参数即为同步函数 一直等到手动点击按钮才会返回。
    # 带timeout参数不为None的为异步函数,timeout时间内无时间或者点击了按钮都会产生结果。
    # 异步方式不会阻塞后面的程序运行。
    for i in range(num):	# 循环
        event, values = window.read(timeout=10)
        if event == 'Cancel' or event is None:
            window.close()
            exit()
            #break
        progress_bar.UpdateBar(i + 1)
        if times_==None:
            pass
            #time.sleep((random.randint(2,27)/100))
        elif times_=='s':
            time.sleep((random.randint(2,27)/100))
        else:
            time.sleep(eval(times))

    window.close()
def key_print(content):
    """输出一串字符串"""
    k.type_string(content)

def key_down(key):
    """
    函数功能：按下按键
    参    数：key:按键值
    """
    key = key.upper()
    vk_code = key_map[key]
    win32api.keybd_event(vk_code,win32api.MapVirtualKey(vk_code,0),0,0)
 
 
def key_up(key):
    """
    函数功能：抬起按键
    参    数：key:按键值
    """
    key = key.upper()
    vk_code = key_map[key]
    win32api.keybd_event(vk_code, win32api.MapVirtualKey(vk_code, 0), win32con.KEYEVENTF_KEYUP, 0)
 
 
def key_press(key):
    """
    函数功能：点击按键（按下并抬起）
    参    数：key:按键值
    """
    key_down(key)
    time.sleep(0.02)
    key_up(key)

import win32api
import win32con
import win32gui


def move(x, y):
  """
  函数功能：移动鼠标到指定位置
  参  数：x:x坐标
       y:y坐标
  """
  win32api.SetCursorPos((x, y))


def get_cur_pos():
  """
  函数功能：获取当前鼠标坐标
  """
  p={"x":0,"y":0}
  pos = win32gui.GetCursorPos()
  p['x']=pos[0]
  p['y']=pos[1]
  return p


def left_click():
  """
  函数功能：鼠标左键点击
  """
  win32api.mouse_event(win32con.MOUSEEVENTF_LEFTDOWN | win32con.MOUSEEVENTF_LEFTUP, 0, 0, 0, 0)


def right_click():
  """
  函数功能：鼠标右键点击
  """
  win32api.mouse_event(win32con.MOUSEEVENTF_RIGHTDOWN | win32con.MOUSEEVENTF_RIGHTUP, 0, 0, 0, 0)


def left_down():
  """
  函数功能：鼠标左键按下
  """
  win32api.mouse_event(win32con.MOUSEEVENTF_LEFTDOWN, 0, 0, 0, 0)


def left_up():
  """
  函数功能：鼠标左键抬起
  """
  win32api.mouse_event(win32con.MOUSEEVENTF_LEFTUP, 0, 0, 0, 0)


def right_down():
  """
  函数功能：鼠标右键按下
  """
  win32api.mouse_event(win32con.MOUSEEVENTF_RIGHTDOWN, 0, 0, 0, 0)


def right_up():
  """
  函数功能：鼠标右键抬起
  """
  win32api.mouse_event(win32con.MOUSEEVENTF_RIGHTUP, 0, 0, 0, 0)
"""运行配置"""
#def command_run(c:str=...) -> None:
#    try:
#        msg = c
#        mg = globals()
#        ml = locals()
#        exec(msg, mg, ml)
#    except Exception as e:
#        try:
#            a=e
#            return e
#        except:
#            print(a)
#        #colorprint('\n'+str(e)+'\n','red')
def command_run(c:str=...) -> None:
    try:
        msg = c
        mg = globals()
        ml = locals()
        exec(msg, mg, ml)
    except Exception as e:
        try:
            return e
        except:
            print(e)
            #raise Exception('')
def make_error(error=''):
    raise Exception(str(error))
class Str:
    content1="""
content="""
    def move_str_list(content):
        #global content1
        f1=open('help_ImportPackage_move.py','w')
        f1.write(self.content1+content)
        f1.close()
        try:
            import help_ImportPackage_move
        except Exception as e:
            pass
        ty=type(help_ImportPackage_move.content)
        if str(ty)!="<class 'list'>":
            raise Exception("'content' is not 'List'#请输入正确的内容")
        return help_ImportPackage_move.content
class tkinter:
    def ScrolledText_CodeBox(self,txtContent):
        """ScrolledText转换为代码框"""
        import idlelib.colorizer as idc
        import idlelib.percolator as idp
        txtContent.focus_set()
        idc.color_config(txtContent)
        txtContent.focus_set()
        #txtContent.config(bg='white',fg='black')
        p = idp.Percolator(txtContent)
        d = idc.ColorDelegator()
        p.insertfilter(d)
    def suspension_window(self,win):
        """将窗口转换为悬浮窗"""
        win.config(bg = '#add123')
        win.wm_attributes('-transparentcolor','#add123')
        win.overrideredirect(1)
        window.attributes('-topmost', 1)
        #win.overrideredirect(1)
    def delete_background(self,win):
        """删除背景"""
        win.config(bg = '#add123')
        win.wm_attributes('-transparentcolor','#add123')
    #def ScrolledText_
class PromptBox:
    """欢迎使用WSL的产品《PromptBox》, 感谢您的支持。谢谢!!!"""
    if_=False
    name=''
    run=False
    sss=0
    wait=True
    button_command1=None
    button_command2=None
    button_command=None
    def _init_(self):
        """运行辅助"""
        #"""运行配置"""
        self.if_=False
        self.name=''
        self.run=False
        self.sss=0
    def close_(self):
        """运行辅助"""
        self.run=False
        #self.windows.destroy()
        self.name=''
    def help_ConfirmBox_(self):
        """运行辅助"""
        if self.button_command!=None:
            self.button_command()
        self.close_()
    def help_ChoiceBox_1(self):
        """运行辅助"""
        if self.button_command1!=None:
            self.button_command1()
        self.close_()
    def help_ChoiceBox_2(self):
        """运行辅助"""
        if self.button_command2!=None:
            self.button_command2()
        self.close_()
    def while_(self,content,name,button_text,color):#args=
        """运行辅助"""
        self.windows=Tk()
        self.windows.title(name)
        self.windows.geometry("500x350+200+100")
        #windows.overrideredirect(True)
        name=str(content)
        self.name+=name+'\n'
        self.sss+=1
        listbox = ScrolledText(self.windows)
        listbox.place(x=0, y=0, width=500, height=300)
        listbox.config(bg='white',fg=color)
        #button=Button(windows,text='确认',command=break)
        #button.pack(anchor='c',pady=20)
        #button.place(x=400, y=310)#x=230
        button=Button(self.windows,text=button_text,command=self.help_ConfirmBox_)
        button.pack(anchor='c',pady=20)
        button.place(x=400, y=310)#x=230
        try:
            while self.run:
                listbox.insert(tkinter.END, self.name)
                #listbox.insert(tkinter.END, name)
                listbox.see(tkinter.END)                                    # ScrolledText组件方法，自动定位到结尾，否则只有消息在涨，窗口拖动条不动
                listbox.update()
                #time.sleep(0.01)
                listbox.delete(0.0, tk.END)
        except Exception as e:
            pass
        self.run=False
        self.name=''
        #self.rctrex.join()
        
    def while_2(self,content,name,button_text1,button_text2,color):#args=
        """运行辅助"""
        self.windows=Tk()
        self.windows.title(name)
        self.windows.geometry("500x350+200+100")
        #windows.overrideredirect(True)
        name=str(content)
        self.name+=name+'\n'
        self.sss+=1
        listbox = ScrolledText(self.windows)
        listbox.place(x=0, y=0, width=500, height=300)
        listbox.config(bg='white',fg=color)
        #button=Button(windows,text='确认',command=break)
        #button.pack(anchor='c',pady=20)
        #button.place(x=400, y=310)#x=230
        button=Button(self.windows,text=button_text1,command=self.help_ChoiceBox_1)
        button.pack(anchor='c',pady=20)
        button.place(x=300, y=310)#x=230
        button=Button(self.windows,text=button_text2,command=self.help_ChoiceBox_2)
        button.pack(anchor='c',pady=20)
        button.place(x=400, y=310)#x=230
        try:
            while self.run:
                listbox.insert(tkinter.END, self.name)
                #listbox.insert(tkinter.END, name)
                listbox.see(tkinter.END)                                    # ScrolledText组件方法，自动定位到结尾，否则只有消息在涨，窗口拖动条不动
                listbox.update()
                #time.sleep(0.01)
                listbox.delete(0.0, tk.END)
        except Exception as e:
            pass
        self.run=False
        self.name=''
        #self.rctrex.join()
        
    def ConfirmBox(self,content='欢迎使用WSL的产品《PromptBox》, 感谢您的支持',
                   name='提示',button_text='确认',button_command=None,
                   color='black'):
        """确认框"""
        #print(self.sss)
        if self.run!=True:
            self.button_command=button_command
            if self.sss==0:
                self.run=True
                self.rctrex = threading.Thread(target=self.while_, args=(content,name,button_text,color), daemon=True)
                # daemon=True 表示创建的子线程守护主线程，主线程退出子线程直接销毁
                self.rctrex.start()
                if self.wait==True:
                    while self.run:
                        pass
            else:
                a=PromptBox()
                if self.wait==True:
                    a.wait=True
                else:
                    if self.wait==False:
                        a.wait=False
                a.ConfirmBox(content,name,button_text,button_command,color)#ChoiceBox
    def ChoiceBox(self,content='欢迎使用WSL的产品《PromptBox》, 感谢您的支持',
                  name='选择',button_text1='确认',button_text2='取消',
                  button_command1=None,button_command2=None,color='black'):
        """选择框"""
        if self.run!=True:
            if self.sss==0:
                self.button_command1=button_command1
                self.button_command2=button_command2
                self.run=True
                self.rctrex = threading.Thread(target=self.while_2, args=(content,name,button_text1,button_text2,color), daemon=True)
                # daemon=True 表示创建的子线程守护主线程，主线程退出子线程直接销毁
                self.rctrex.start()
                if self.wait==True:
                    while self.run:
                        pass
            else:
                a=PromptBox()
                if self.wait==True:
                    a.wait=True
                a.ChoiceBox(content,name,button_text1,button_text2,button_command1,button_command2,color)#e,name,button_text1,button_text2,button_command1,button_command2,color
    def LoginBox(self,new=True):
        """登录界面"""
        if new!=True and new!=False:
            raise Exception("'new' is not 'True' or 'False'#请输入正确的内容")
        try:
            if new==False:
                import PromptBox_LoginBox as LoginBox
            elif new==True:
                import PromptBox_LoginBox_new as LoginBox
            else:
                raise Exception("'new' is not 'True' or 'False'#请输入正确的内容: 'True' or 'False'")
            while LoginBox.run:
                pass
            if LoginBox.name!=None:
                return LoginBox.name
            else:
                return None
        except Exception as e:
            pass
    def a(self,name='启动中',color='black'):
        #█
        windows=Tk()
        windows.title(name)
        windows.geometry("500x50+200+100")
        #windows.overrideredirect(True)
        #name=str(content)
        #self.name+=name+'\n'
        #self.sss+=1
        sss=''
        listbox = ScrolledText(windows)
        listbox.place(x=0, y=0, width=500, height=300)
        listbox.config(bg='white',fg=color)
        #button=Button(windows,text='确认',command=break)
        #button.pack(anchor='c',pady=20)
        #button.place(x=400, y=310)#x=230
        #button=Button(self.windows,text=button_text1,command=self.help_ChoiceBox_1)
        #button.pack(anchor='c',pady=20)
        #button.place(x=300, y=310)#x=230
        #button=Button(self.windows,text=button_text2,command=self.help_ChoiceBox_2)
        #button.pack(anchor='c',pady=20)
        #button.place(x=400, y=310)#x=230
        try:
            while True:
                listbox.insert(tkinter.END, sss)
                #listbox.insert(tkinter.END, name)
                listbox.see(tkinter.END)                                    # ScrolledText组件方法，自动定位到结尾，否则只有消息在涨，窗口拖动条不动
                listbox.update()
                time.sleep(0.01)
                sss+='█'##�
                listbox.delete(0.0, tk.END)
        except Exception as e:
            print(e)
            pass

def HelpPromptBox():
    a=PromptBox()
    help(a)

hh='''
def progress_bar(name='进度条',times_=None):"""进度条"""

def key_print(content):"""输出一串字符串"""

def key_down(key):"""按下按键"""

def key_up(key):"""抬起按键"""

def key_press(key):"""点击按键（按下并抬起）"""

def move(x, y):"""移动鼠标到指定位置"""

def get_cur_pos():"""获取当前鼠标坐标"""

def left_click():"""鼠标左键点击"""

def right_click():"""鼠标右键点击"""

def left_down():"""鼠标左键按下"""

def left_up():"""鼠标左键抬起"""

def right_down():"""鼠标右键按下"""

def right_up():"""鼠标右键抬起"""

command_run(c:str=...) -> None:

make_error(error=''):

class Str:
│
├─move_str_list(content):
┴
class tkinter:
│
├─ScrolledText_CodeBox(self,txtContent):"""ScrolledText转换为代码框"""
│
├─suspension_window(self,win):"""将窗口转换为悬浮窗"""
│
├─delete_background(self,win):"""删除背景"""
┴
class PromptBox:
│
├─_init_(self):"""运行辅助"""
│
├─close_(self):"""运行辅助"""
│
├─help_ConfirmBox_(self):"""运行辅助"""
│
├─help_ChoiceBox_1(self):"""运行辅助"""
│
├─help_ChoiceBox_2(self):"""运行辅助"""
│
├─while_(self,content,name,button_text,color):"""运行辅助"""
│
├─while_2(self,content,name,button_text1,button_text2,color):"""运行辅助"""
│
├─ConfirmBox(self,content='欢迎使用WSL的产品《PromptBox》, 感谢您的支持'
│             ,name='提示',button_text='确认'
│             ,button_command=None,color='black'):"""确认框"""
│
├─ChoiceBox(self,content='欢迎使用WSL的产品《PromptBox》, 感谢您的支持'
│          ,name='选择',button_text1='确认'
│          ,button_text2='取消',button_command1=None
│          ,button_command2=None,color='black'):"""选择框"""
│
├─LoginBox(self,new=True):"""登录界面"""
┴
'''


#┬

def Help():
    print(hh)

print('ImPa 2.1.0 (SDL 2.0.16, Python 3.10.0)'+'\n'+"you can input 'self.Help()' and have help ")#'Hello from the PromptBox community. https://')#'欢迎使用WSL的产品《PromptBox》, 感谢您的支持。谢谢!!!')#'PromptBox 2.1.0 (SDL 2.0.16, Python 3.10.0)'+'\n'+'Hello from the PromptBox community. https://blog.csdn.net/computer123_wind/article/details/126629447'

"""
PromptBox功能：

name=PromptBox.LoginBox()                                                                                功能：登录，把用户名给到  ' name '

PromptBox.ChoiceBox()                                                                                         功能：选择，执行相应代码

PromptBox.ConfirmBox(content,name,button_text,button_command,color)                                                                                                 功能：提示"""

#command_run('print("a")')

#LoginBox参数功能：

#ChoiceBox参数功能：

#ConfirmBox参数功能：

#a=PromptBox()

#a.a()
        
#def p1():

#    print('ok')

#help(a)

#b=a.LoginBox()

#a.ChoiceBox(button_command1=p1)

#a.ChoiceBox(button_command1=p1)

#a.ConfirmBox(button_command=p1)

#a=PromptBox()

#a.LoginBox()
