# -*- coding: utf-8 -*-
"""
Created on Sun Aug  5 10:34:10 2018
@author: Administrator
"""
import tkinter as tk
import tkinter.messagebox
import pickle
#窗口#⚙
run=True
n=2
n3=2
def setup():
    pass
def n1():
    global n
    global R1
    global var_usr_pwd
    global window
    global var_usr_name,var_usr_pwd
    na=var_usr_name.get()
    nn=var_usr_pwd.get()
    screenWidth = window.winfo_screenwidth()   # 屏幕宽度
    screenHeight = window.winfo_screenheight()  # 屏幕高度
    w = 450
    h = 300
    x = (screenWidth - w)/2
    y = (screenHeight - h)/2
    if n==2:
        window.destroy()
        #var_usr_pwd=tk.StringVar()
        #entry_usr_pwd=tk.Entry(window,textvariable=var_usr_pwd)
        #entry_usr_pwd.place(x=160,y=190)
        #entry_usr_pwd.grid(row=1)
        window=tk.Tk()
        window.title('登录')
        #window.geometry("%dx%d+%d+%d" % (w, h, x, y))
        window.geometry('450x300')
        window.geometry("%dx%d+%d+%d" % (w, h, x, y))
        radio = tk.IntVar()
        #画布放置图片
        canvas=tk.Canvas(window,height=300,width=500)
        #imagefile=tk.PhotoImage(file='截图20220815170728.png')
        #image=canvas.create_image(0,0,anchor='nw',image=imagefile)
        #canvas.pack(side='top')
        #标签 用户名密码
        tk.Label(window,text='用户名:').place(x=100,y=150)
        tk.Label(window,text='密码:').place(x=100,y=190)
        #用户名输入框
        var_usr_name=tk.StringVar(value=na)
        entry_usr_name=tk.Entry(window,textvariable=var_usr_name)
        entry_usr_name.place(x=160,y=150)
        #R2 = tk.Radiobutton(window, text="隐藏", variable=radio, value=2 )#,command=p)  
        #R2.place(x=320,y=150)
        #密码输入框
        var_usr_pwd=tk.StringVar(value=nn)
        entry_usr_pwd=tk.Entry(window,textvariable=var_usr_pwd)
        entry_usr_pwd.place(x=160,y=190)
        #R1 = tk.Checkbutton(window, text="显示",command=n1)  
        #R1.place(x=320,y=190)
        
        R1=tk.Button(window,text='隐藏',command=n1)
        R1.place(x=320,y=190)

        bt_setup=tk.Button(window,text='设置⚙',command=setup)
        bt_setup.place(x=146,y=230)#(x=100,y=230)
        bt_login=tk.Button(window,text='登录',command=usr_log_in)
        bt_login.place(x=196,y=230)#(x=150,y=230)
        bt_logup=tk.Button(window,text='注册',command=aaaaa)#usr_sign_up)
        bt_logup.place(x=230,y=230)
        bt_logquit=tk.Button(window,text='退出',command=usr_sign_quit)
        bt_logquit.place(x=264,y=230)#(x=280,y=230)
        #主循环
        #window.mainloop()
        n=1
    elif n==1:
        window.destroy()
        #var_usr_pwd=tk.StringVar()
        #entry_usr_pwd=tk.Entry(window,textvariable=var_usr_pwd,show='*')
        #entry_usr_pwd.place(x=160,y=190)
        window=tk.Tk()
        window.title('登录')
        window.geometry('450x300')
        window.geometry("%dx%d+%d+%d" % (w, h, x, y))
        radio = tk.IntVar()
        #画布放置图片
        canvas=tk.Canvas(window,height=300,width=500)
        #imagefile=tk.PhotoImage(file='截图20220815170728.png')
        #image=canvas.create_image(0,0,anchor='nw',image=imagefile)
        #canvas.pack(side='top')
        #标签 用户名密码
        tk.Label(window,text='用户名:').place(x=100,y=150)
        tk.Label(window,text='密码:').place(x=100,y=190)
        #用户名输入框
        var_usr_name=tk.StringVar(value=na)
        entry_usr_name=tk.Entry(window,textvariable=var_usr_name)
        entry_usr_name.place(x=160,y=150)
        #R2 = tk.Radiobutton(window, text="隐藏", variable=radio, value=2 )#,command=p)  
        #R2.place(x=320,y=150)
        #密码输入框
        var_usr_pwd=tk.StringVar(value=nn)
        entry_usr_pwd=tk.Entry(window,textvariable=var_usr_pwd,show='*')
        entry_usr_pwd.place(x=160,y=190)
        #R1 = tk.Checkbutton(window, text="显示",command=n1)  
        #R1.place(x=320,y=190)
        
        R1=tk.Button(window,text='显示',command=n1)
        R1.place(x=320,y=190)

        bt_setup=tk.Button(window,text='设置⚙',command=setup)
        bt_setup.place(x=146,y=230)#(x=100,y=230)
        bt_login=tk.Button(window,text='登录',command=usr_log_in)
        bt_login.place(x=196,y=230)#(x=150,y=230)
        bt_logup=tk.Button(window,text='注册',command=aaaaa)#usr_sign_up)
        bt_logup.place(x=230,y=230)
        bt_logquit=tk.Button(window,text='退出',command=usr_sign_quit)
        bt_logquit.place(x=264,y=230)#(x=280,y=230)
        #主循环
        #window.mainloop()
        n=2
window=tk.Tk()
window.title('登录')
window.geometry('450x300+415+210')
window.resizable(False,False)
radio = tk.IntVar()
#画布放置图片
canvas=tk.Canvas(window,height=300,width=500)
#imagefile=tk.PhotoImage(file='截图20220815170728.png')
#image=canvas.create_image(0,0,anchor='nw',image=imagefile)
#canvas.pack(side='top')
#标签 用户名密码
tk.Label(window,text='用户名:').place(x=100,y=150)
tk.Label(window,text='密码:').place(x=100,y=190)
#用户名输入框
var_usr_name=tk.StringVar()
entry_usr_name=tk.Entry(window,textvariable=var_usr_name)
entry_usr_name.place(x=160,y=150)
#R2 = tk.Radiobutton(window, text="隐藏", variable=radio, value=2 )#,command=p)  
#R2.place(x=320,y=150)
#密码输入框
var_usr_pwd=tk.StringVar()
entry_usr_pwd=tk.Entry(window,textvariable=var_usr_pwd,show='*')
entry_usr_pwd.place(x=160,y=190)
#R1 = tk.Checkbutton(window, text="显示",command=n1)  
#R1.place(x=320,y=190)
R1=tk.Button(window,text='显示',command=n1)
R1.place(x=320,y=190)
#R1.text='a'
#R1.update()
#R1.destroy()
name=None
a_name=None
a_pwd=None
aaaaaa=True
#登录函数
def usr_log_in():
    global name,a_name,a_pwd
    #输入框获取用户名密码
    usr_name=var_usr_name.get()
    a_name=var_usr_name.get()
    usr_pwd=var_usr_pwd.get()
    a_pwd=var_usr_pwd.get()
    #从本地字典获取用户信息，如果没有则新建本地数据库
    try:
        with open('usr_info.pickle','rb') as usr_file:
            usrs_info=pickle.load(usr_file)
    except FileNotFoundError:
        with open('usr_info.pickle','wb') as usr_file:
            usrs_info={'admin':'admin'}
            pickle.dump(usrs_info,usr_file)
    #判断用户名和密码是否匹配
    if usr_name in usrs_info:
        if usr_pwd == usrs_info[usr_name]:
            name=usr_name
            tk.messagebox.showinfo(title='welcome',
                                   message='欢迎您：'+usr_name)
            window.destroy()
        else:
            tk.messagebox.showerror(message='密码错误')
    #用户名密码不能为空
    elif usr_name=='' or usr_pwd=='' :
        tk.messagebox.showerror(message='用户名或密码为空')
    #不在数据库中弹出是否注册的框
    else:
        is_signup=tk.messagebox.askyesno('欢迎','您还没有注册，是否现在注册')
        if is_signup:
            usr_sign_up()
na1=''
nn1=''
np1=''
#iif=False
iif=True
#def quit_exit():
#    global iif
#    window.attributes("-disabled", 0)
#    #iif=False
#    iif=True
def aaaaa():
    global iif
    iif=True
    usr_sign_up()
#注册函数
def usr_sign_up():
    global a_name,a_pwd,aaaaaa,n3,iif,na1,nn1,np1
    #print(iif)
    def quit_exit():
        global iif,n3
        n3=2
        iif=True
        window.attributes("-disabled", 0)
        window_sign_up_exit()
    def usr_sign_up1():
        #global window_sign_up
        #window_sign_up.destroy()
        window.attributes("-disabled", 0)
        aa()
        window_sign_up_exit()
        usr_sign_up()
    def aa():
        global na1,nn1,np1
        na1=new_name.get()
        nn1=new_pwd.get()
        np1=new_pwd_confirm.get()
    def window_sign_up_exit():
        #global window_sign_up
        window_sign_up.destroy()
    def n2():
        global n3
        global R2
        #global var_usr_pwd
        global window_sign_up
        aa()
        global na,nn,np
        #print(na,nn,np)
        #global new_name,new_pwd,new_pwd_confirm
        #na=new_name.get()
        #nn=new_pwd.get()
        #np=new_pwd_confirm.get()
        
        #na=new_name.get()
        #nn=new_pwd.get()
        #np=new_pwd_confirm.get()
        if n3==2:
            #window_sign_up.destroy()
            window_sign_up_exit()
            window_sign_up=tk.Toplevel(window)
            window_sign_up.geometry('350x200')
            window_sign_up.title('注册')
            window_sign_up.transient(root)
            #用户名变量及标签、输入框
            #print(a_name)
            new_name=tk.StringVar(value=na)#name=a_name)
            #help(new_name)
            tk.Label(window_sign_up,text='用户名：').place(x=10,y=10)
            tk.Entry(window_sign_up,textvariable=new_name).place(x=150,y=10)
            #if a_name!=None:
            #    new_name.insert(tkinter.END, a_name)
            #    new_name.see(tkinter.END)
            #    new_name.update()
            #密码变量及标签、输入框
            new_pwd=tk.StringVar(value=nn)
            tk.Label(window_sign_up,text='请输入密码：').place(x=10,y=50)
            tk.Entry(window_sign_up,textvariable=new_pwd).place(x=150,y=50)#140
            R2=tk.Button(window_sign_up,text='隐藏',command=n2)
            R2.place(x=290,y=50)
            #if a_pwd!=None:
            #    new_pwd.insert(tkinter.END, a_pwd)
            #    new_pwd.see(tkinter.END)
            #    new_pwd.update()
            #重复密码变量及标签、输入框
            new_pwd_confirm=tk.StringVar(value=np)
            tk.Label(window_sign_up,text='请再次输入密码：').place(x=10,y=90)
            tk.Entry(window_sign_up,textvariable=new_pwd_confirm).place(x=150,y=90)
            #if a_pwd!=None:
            #    new_pwd_confirm.insert(tkinter.END, a_pwd)
            #    new_pwd_confirm.see(tkinter.END)
            #    new_pwd_confirm.update()
            #确认注册按钮及位置
            bt_confirm_sign_up=tk.Button(window_sign_up,text='确认注册',
                                         command=signtowcg)
            bt_confirm_sign_up.place(x=150,y=130)
            n3=1
        elif n3==1:
            #window_sign_up.destroy()
            window_sign_up_exit()
            window_sign_up=tk.Toplevel(window)
            window_sign_up.geometry('350x200')
            window_sign_up.title('注册')
            window_sign_up.transient(root)
            #用户名变量及标签、输入框
            #print(a_name)
            new_name=tk.StringVar(value=na)#name=a_name)
            #help(new_name)
            tk.Label(window_sign_up,text='用户名：').place(x=10,y=10)
            tk.Entry(window_sign_up,textvariable=new_name).place(x=150,y=10)
            #if a_name!=None:
            #    new_name.insert(tkinter.END, a_name)
            #    new_name.see(tkinter.END)
            #    new_name.update()
            #密码变量及标签、输入框
            new_pwd=tk.StringVar(value=nn)
            tk.Label(window_sign_up,text='请输入密码：').place(x=10,y=50)
            tk.Entry(window_sign_up,textvariable=new_pwd,show='*').place(x=150,y=50)#140
            R2=tk.Button(window_sign_up,text='显示',command=n2)
            R2.place(x=290,y=50)
            #if a_pwd!=None:
            #    new_pwd.insert(tkinter.END, a_pwd)
            #    new_pwd.see(tkinter.END)
            #    new_pwd.update()
            #重复密码变量及标签、输入框
            new_pwd_confirm=tk.StringVar(value=np)
            tk.Label(window_sign_up,text='请再次输入密码：').place(x=10,y=90)
            tk.Entry(window_sign_up,textvariable=new_pwd_confirm,show='*').place(x=150,y=90)
            #if a_pwd!=None:
            #    new_pwd_confirm.insert(tkinter.END, a_pwd)
            #    new_pwd_confirm.see(tkinter.END)
            #    new_pwd_confirm.update()
            #确认注册按钮及位置
            bt_confirm_sign_up=tk.Button(window_sign_up,text='确认注册',
                                         command=signtowcg)
            bt_confirm_sign_up.place(x=150,y=130)
            n3=2
    #确认注册时的相应函数
    def signtowcg():
        import tkinter
        #获取输入框内的内容
        nn=new_name.get()
        np=new_pwd.get()
        npf=new_pwd_confirm.get()
  
        #本地加载已有用户信息,如果没有则已有用户信息为空
        try:
            with open('usr_info.pickle','rb') as usr_file:
                exist_usr_info=pickle.load(usr_file)
        except FileNotFoundError:
            exist_usr_info={}           
             
        #检查用户名存在、密码为空、密码前后不一致
        if nn in exist_usr_info:
            tk.messagebox.showerror('错误','用户名已存在')
        elif np =='' or nn=='':
            tk.messagebox.showerror('错误','用户名或密码为空')
        elif np !=npf:
            tk.messagebox.showerror('错误','密码前后不一致')
        #注册信息没有问题则将用户名密码写入数据库
        else:
            exist_usr_info[nn]=np
            with open('usr_info.pickle','wb') as usr_file:
                pickle.dump(exist_usr_info,usr_file)
            tk.messagebox.showinfo('欢迎','注册成功')
            #注册成功关闭注册框
            window.attributes("-disabled", 0)
            window_sign_up.destroy()
    if n3==2 and iif!=True:
        #window_sign_up.destroy()
        #window_sign_up_exit()
        window_sign_up=tk.Toplevel(window)
        window.resizable(False,False)
        window_sign_up.geometry('350x200')
        window_sign_up.geometry('350x200+415+210')
        window_sign_up.attributes('-topmost', 1)
        window_sign_up.attributes('-topmost', 0)
        window_sign_up.title('注册')
        window_sign_up.transient(window)
        window_sign_up.protocol("WM_DELETE_WINDOW", quit_exit)
        #用户名变量及标签、输入框
        #print(a_name)
        new_name=tk.StringVar(value=na1)#name=a_name)
        #help(new_name)
        tk.Label(window_sign_up,text='用户名：').place(x=10,y=10)
        tk.Entry(window_sign_up,textvariable=new_name).place(x=150,y=10)
        #if a_name!=None:
        #    new_name.insert(tkinter.END, a_name)
        #    new_name.see(tkinter.END)
        #    new_name.update()
        #密码变量及标签、输入框
        new_pwd=tk.StringVar(value=nn1)
        tk.Label(window_sign_up,text='请输入密码：').place(x=10,y=50)
        tk.Entry(window_sign_up,textvariable=new_pwd).place(x=150,y=50)#140
        R2=tk.Button(window_sign_up,text='隐藏',command=usr_sign_up1)
        R2.place(x=300,y=50)
        #if a_pwd!=None:
        #    new_pwd.insert(tkinter.END, a_pwd)
        #    new_pwd.see(tkinter.END)
        #    new_pwd.update()
        #重复密码变量及标签、输入框
        new_pwd_confirm=tk.StringVar(value=np1)
        tk.Label(window_sign_up,text='请再次输入密码：').place(x=10,y=90)
        tk.Entry(window_sign_up,textvariable=new_pwd_confirm).place(x=150,y=90)
        #if a_pwd!=None:
        #    new_pwd_confirm.insert(tkinter.END, a_pwd)
        #    new_pwd_confirm.see(tkinter.END)
        #    new_pwd_confirm.update()
        #确认注册按钮及位置
        bt_confirm_sign_up=tk.Button(window_sign_up,text='确认注册',
                                     command=signtowcg)
        bt_confirm_sign_up.place(x=150,y=130)
        window.attributes("-disabled", 1)
        window_sign_up.protocol("WM_DELETE_WINDOW", quit_exit)
        n3=1
    elif n3==1 and iif!=True:
        #window_sign_up.destroy()
        #window_sign_up_exit()
        window_sign_up=tk.Toplevel(window)
        window.resizable(False,False)
        window_sign_up.geometry('350x200')
        window_sign_up.geometry('350x200+415+210')
        window_sign_up.attributes('-topmost', 1)
        window_sign_up.attributes('-topmost', 0)
        window_sign_up.title('注册')
        window_sign_up.transient(window)
        window_sign_up.protocol("WM_DELETE_WINDOW", quit_exit)
        #用户名变量及标签、输入框
        #print(a_name)
        new_name=tk.StringVar(value=na1)#name=a_name)
        #help(new_name)
        tk.Label(window_sign_up,text='用户名：').place(x=10,y=10)
        tk.Entry(window_sign_up,textvariable=new_name).place(x=150,y=10)
        #if a_name!=None:
        #    new_name.insert(tkinter.END, a_name)
        #    new_name.see(tkinter.END)
        #    new_name.update()
        #密码变量及标签、输入框
        new_pwd=tk.StringVar(value=nn1)
        tk.Label(window_sign_up,text='请输入密码：').place(x=10,y=50)
        tk.Entry(window_sign_up,textvariable=new_pwd,show='*').place(x=150,y=50)#140
        R2=tk.Button(window_sign_up,text='显示',command=usr_sign_up1)
        R2.place(x=300,y=50)
        #if a_pwd!=None:
        #    new_pwd.insert(tkinter.END, a_pwd)
        #    new_pwd.see(tkinter.END)
        #    new_pwd.update()
        #重复密码变量及标签、输入框
        new_pwd_confirm=tk.StringVar(value=np1)
        tk.Label(window_sign_up,text='请再次输入密码：').place(x=10,y=90)
        tk.Entry(window_sign_up,textvariable=new_pwd_confirm,show='*').place(x=150,y=90)
        #if a_pwd!=None:
        #    new_pwd_confirm.insert(tkinter.END, a_pwd)
        #    new_pwd_confirm.see(tkinter.END)
        #    new_pwd_confirm.update()
        #确认注册按钮及位置
        bt_confirm_sign_up=tk.Button(window_sign_up,text='确认注册',
                                     command=signtowcg)
        bt_confirm_sign_up.place(x=150,y=130)
        window.attributes("-disabled", 1)
        window_sign_up.protocol("WM_DELETE_WINDOW", quit_exit)
        n3=2
    elif iif==True:
        #新建注册界面
        window_sign_up=tk.Toplevel(window)
        window.resizable(False,False)
        window_sign_up.geometry('350x200')
        window_sign_up.geometry('350x200+415+210')
        window_sign_up.attributes('-topmost', 1)
        window_sign_up.attributes('-topmost', 0)
        window_sign_up.title('注册')
        window_sign_up.transient(window)
        window_sign_up.protocol("WM_DELETE_WINDOW", quit_exit)
        #用户名变量及标签、输入框
        #print(a_name)
        if a_name!=None:
            new_name=tk.StringVar(value=a_name)#name=a_name)
        else:
            new_name=tk.StringVar()
        #help(new_name)
        tk.Label(window_sign_up,text='用户名：').place(x=10,y=10)
        tk.Entry(window_sign_up,textvariable=new_name).place(x=150,y=10)
        #if a_name!=None:
        #    new_name.insert(tkinter.END, a_name)
        #    new_name.see(tkinter.END)
        #    new_name.update()
        #密码变量及标签、输入框
        if a_pwd!=None:
            new_pwd=tk.StringVar(value=a_pwd)
        else:
            new_pwd=tk.StringVar()
        tk.Label(window_sign_up,text='请输入密码：').place(x=10,y=50)
        tk.Entry(window_sign_up,textvariable=new_pwd,show='*').place(x=150,y=50)#140
        R2=tk.Button(window_sign_up,text='显示',command=usr_sign_up1)
        R2.place(x=300,y=50)
        
        #if a_pwd!=None:
        #    new_pwd.insert(tkinter.END, a_pwd)
        #    new_pwd.see(tkinter.END)
        #    new_pwd.update()
        #重复密码变量及标签、输入框
        if a_pwd!=None:
            new_pwd_confirm=tk.StringVar(value=a_pwd)
        else:
            new_pwd_confirm=tk.StringVar()
        tk.Label(window_sign_up,text='请再次输入密码：').place(x=10,y=90)
        tk.Entry(window_sign_up,textvariable=new_pwd_confirm,show='*').place(x=150,y=90)
        #if a_pwd!=None:
        #    new_pwd_confirm.insert(tkinter.END, a_pwd)
        #    new_pwd_confirm.see(tkinter.END)
        #    new_pwd_confirm.update()
        #确认注册按钮及位置
        bt_confirm_sign_up=tk.Button(window_sign_up,text='确认注册',
                                     command=signtowcg)
        bt_confirm_sign_up.place(x=150,y=130)
        window.attributes("-disabled", 1)
        window_sign_up.protocol("WM_DELETE_WINDOW", quit_exit)
        #window_register.protocol("WM_DELETE_WINDOW", window_register_close_handler)
        iif=False
#global window_sign_up
#退出的函数
def usr_sign_quit():
    global window_sign_up
    window.destroy()
    #window_sign_up.destroy()
    #exit()
#登录 注册按钮
bt_setup=tk.Button(window,text='设置⚙',command=setup)
bt_setup.place(x=146,y=230)#(x=100,y=230)
bt_login=tk.Button(window,text='登录',command=usr_log_in)
bt_login.place(x=196,y=230)#(x=150,y=230)
bt_logup=tk.Button(window,text='注册',command=aaaaa)#usr_sign_up)
bt_logup.place(x=230,y=230)
bt_logquit=tk.Button(window,text='退出',command=usr_sign_quit)
bt_logquit.place(x=264,y=230)#(x=280,y=230)
#主循环
#window.overrideredirect(1)#iconify()
#window.attributes("-toolwindow", 1)#overrideredirect(1)
#window.iconify()
window.mainloop()
run=False
#print(name)
