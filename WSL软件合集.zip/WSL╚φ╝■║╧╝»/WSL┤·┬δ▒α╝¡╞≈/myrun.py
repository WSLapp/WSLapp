def rgwtgxrg():
    exit()
