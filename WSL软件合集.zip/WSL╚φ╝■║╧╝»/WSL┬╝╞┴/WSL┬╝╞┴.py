from PIL import ImageGrab
import numpy as np
import cv2
import os
import jpype

def Recording(tag=1):
  # 录屏开始时创建test.txt,作为结束录屏的条件
  #Python学习群827513319
  if not os.path.exists('test.txt'):
    f = open('test.txt', 'w')
    f.close()
  # 根据tag值判断自定义录屏或全录屏
  if tag == 1:
    r = SelectRegion()
    record_region = (r.x, r.y, r.w + r.x, r.h + r.y) # 自定义录屏的范围（左上坐标、右下坐标）
  elif tag == 2:
    record_region = None
  image = ImageGrab.grab(record_region) # 获取指定范围的屏幕对象
  width, height = image.size
  fourcc = cv2.VideoWriter_fourcc(*'XVID')
  f1=open('num.txt','r')
  name=f1.read()
  f1.close()
  video = cv2.VideoWriter(('.\WSL录屏_'+name), fourcc, 5, (width, height))#'test.mp4', fourcc, 5, (width, height)) # 默认视频为25帧
  while True:
    captureImage = ImageGrab.grab(record_region) # 抓取指定范围的屏幕
    frame = cv2.cvtColor(np.array(captureImage), cv2.COLOR_RGB2BGR)
    video.write(frame) # 将每帧画面写视频文件
    # 停止录屏的条件：test.txt被删除
    if not os.path.exists('test.txt'):
      break
  video.release()
  cv2.destroyAllWindows()

def SelectRegion():
  jvmPath = jpype.getDefaultJVMPath()
  jpype.startJVM(jvmPath, '-ea', '-Djava.class.path=F:\\sikuli\\1\\sikulixapi.jar') #加载jar包路径
  Screen = jpype.JClass('org.sikuli.script.Screen')
  myscreen = Screen()
  region = myscreen.selectRegion() # 自定义获取屏幕范围
  return region

def StopRecording():
  os.remove('test.txt') #停止录屏的触发条件

#if __name__ == "__main__":
 # Recording()
import sys
from PyQt5.QtCore import *
from PyQt5.QtWidgets import *
import time
import win32api,win32con
#from recording import *

class WorkThread(QThread):
  def __init__(self, n):
    super(WorkThread, self).__init__()
    self.n = n

  def run(self):
    if self.n == 1:
      Minimize_Window()
      Recording(1)
    elif self.n == 2:
      Minimize_Window()
      Recording(2)
    else:
      StopRecording()

def Minimize_Window():
  win32api.keybd_event(91, 0, 0, 0)
  time.sleep(0.5)
  win32api.keybd_event(40, 0, 0, 0)
  time.sleep(0.5)
  win32api.keybd_event(91, 0, win32con.KEYEVENTF_KEYUP, 0)
  win32api.keybd_event(40, 0, win32con.KEYEVENTF_KEYUP, 0)

class Ui_Mainwindow():
  def setupUi(self, top):
    # 垂直布局类QVBoxLayout
    layout = QVBoxLayout(top)
    # 添加录屏相关按钮
    #button1 = QPushButton("自定义录屏")
    #layout.addWidget(button1)
    button2 = QPushButton("开始录屏")
    layout.addWidget(button2)
    button3 = QPushButton("停止录屏")
    layout.addWidget(button3)
    self.text = QPlainTextEdit('欢迎使用！')
    layout.addWidget(self.text)
    #button1.clicked.connect(lambda: self.work(1))
    button2.clicked.connect(lambda: self.work(2))
    button3.clicked.connect(lambda: self.work(3))

  def work(self, n):
    if n == 1 :
      print('已选择自定义录屏：')
      self.text.setPlainText('正在录屏中，请等待……')
    elif n == 2 :
      print('已选择全屏录屏：')
      self.text.setPlainText('正在录屏中，请等待……')
    else:
      print('已选择结束录屏：')
      self.text.setPlainText('录屏结束！(点击关闭按钮，可退出程序！)')
    self.workThread = WorkThread(n)
    self.workThread.start()

if __name__ == "__main__":
  app = QApplication(sys.argv)
  top = QWidget()
  top.setWindowTitle('WSL录屏')
  top.resize(300, 170)
  ui = Ui_Mainwindow()
  ui.setupUi(top)
  top.show()
  sys.exit(app.exec_())# coding=utf-8
