import cv2
import time
import cvzone
import numpy as np
from cvzone.HandTrackingModule import HandDetector
from pynput.keyboard import Controller
#import tkinter as tk
import tkinter
from PIL import Image, ImageTk
import win32con
import win32api
import sys

run=True

def exi():
    global run
    run=False
    w1.destroy()
    #exit()
w1 = tkinter.Tk()
long=500
high=300
w1.geometry(str(long)+"x"+str(high)+"+200+100")
w1.title('WSL手势鼠标')
w1.protocol("WM_DELETE_WINDOW", exi)
w1.attributes('-topmost', 1)
w1.resizable(0,0)
#w.attributes("-toolwindow", 1)

#img1 = Image1.open('./photo.png')
#photo = ImageTk.PhotoImage(img1)
#image_Label = tkinter.Label(w, image=photo)
#image_Label.pack()
#w.mainloop()　　

#imageLabel_win = tk.Tk()
 
#链接摄像头
cap = cv2.VideoCapture(0)#读取摄像头
# 设置窗口大小：1280*720
cap.set(3, 1280)#窗口宽度
cap.set(4, 700)#窗口高度
 
#识别手势
keyboard = Controller()#键盘控制器
detector = HandDetector(mode=False,  # 视频流图像
                        maxHands=2 ,  # 最多检测一只手
                        detectionCon=0.8,  # 最小检测置信度
                        minTrackCon=0.5)  # 最小跟踪置信度
 
#设置按键类
class Button():
    def __init__(self, pos:list, text:str, size=[75, 75]):
        self.pos = pos#位置
        self.size = size#大小
        self.text = text#文本
 
keys_value = [[' ','u',' '],['l',' ','r',' ','[',']'],[' ','d',' '],['{','}']]
key_map = {
    "0": 49, "1": 50, "2": 51, "3": 52, "4": 53, "5": 54, "6": 55, "7": 56, "8": 57, "9": 58,
    "A": 65, "B": 66, "C": 67, "D": 68, "E": 69, "F": 70, "G": 71, "H": 72, "I": 73, "J": 74,
    "K": 75, "L": 76, "M": 77, "N": 78, "O": 79, "P": 80, "Q": 81, "R": 82, "S": 83, "T": 84,
    "U": 85, "V": 86, "W": 87, "X": 88, "Y": 89, "Z": 90
}
# 将不同属性的按键对象，存放在buttonList列表里
buttonList = []
for i in range(len(keys_value)):
    for index, key in enumerate(keys_value[i]):
        len_key = len(key)
        if len_key > 1:# 计算按键的字符个数，当超过1时，调整按键的大小；当超过四时，根据字符的个数更新按键大小
            buttonList.append(Button((80 + 100 * index, 100 * (i + 1)), key, size=(55 * (len_key // 4 + 2), 75)))
        else:
            buttonList.append(Button((80 + 100 * index, 100 * (i + 1)), key))
 
#绘制键盘
# 定义函数，调用buttonList列表中所有的Button对象，并进行绘制；另外进行透明的显示
def drawAll_transparence(img, buttonList):
    imgNew = np.zeros_like(img, dtype=np.uint8)#创建img的同型矩阵
    for button in buttonList:#遍历每个按键
        # 根据每个矩形框中心点的位置，在一帧图像中画上每个矩形框
        x, y = button.pos#获取按键位置
        w, h = button.size#获取按键大小
        cv2.rectangle(imgNew, (x, y), (x + w, y + h), (255, 0, 255), cv2.FILLED)#绘制矩形，并填充
        cvzone.cornerRect(imgNew, (x, y, w, h), 20,rt=0,colorC=(0, 255, 0))#绘制边角
        cv2.putText(imgNew, button.text, (x + 25, y + 60), cv2.FONT_HERSHEY_PLAIN, 3, (255, 255, 255), thickness=3)#写入文字
    out = img.copy()
    alpha = 0.3
    mask = imgNew.astype(bool)#转换数据类型
    out[mask] = cv2.addWeighted(img, alpha, imgNew, 1 - alpha, 0)[mask]#透明处理
    return out
 
real_num_text = 0  # 记录finalText中真实存在的字符个数
num_text = 0  # 记录finalText中的字符个数，为了保证能每60个字符换一次行
finalText = ""  # 定义输出文本为空，字符串
# 每次读取一帧图像，除非有break出现，否则一直在读取并显示变化后摄像头每一帧的图像
ab=1
import pykeyboard
k=pykeyboard.PyKeyboard()
#help(k)
#print(dir(k))
def key_down(key):
    """
    函数功能：按下按键
    参    数：key:按键值
    """
    key = key.upper()
    vk_code = key_map[key]
    win32api.keybd_event(vk_code,win32api.MapVirtualKey(vk_code,0),0,0)
 
 
def key_up(key):
    """
    函数功能：抬起按键
    参    数：key:按键值
    """
    key = key.upper()
    vk_code = key_map[key]
    win32api.keybd_event(vk_code, win32api.MapVirtualKey(vk_code, 0), win32con.KEYEVENTF_KEYUP, 0)
def key_press(key):
    """
    函数功能：点击按键（按下并抬起）
    参    数：key:按键值
    """
    key_down(key)
    time.sleep(0.02)
    key_up(key)
def mouse_move(x=0,y=0):
    import win32api
    import win32con
    import win32gui
    import pyautogui as ui
    import pyautogui as pg
    #from pymouse import PyMouse
    #m = ui.PyMouse()
    #ui.FAILSAFE = False
    x1,y1=pg.position()
    #m.move(x1+x, y1+y)
    win32api.SetCursorPos((x1+x, y1+y))
    #ui.moveTo(x1+x, y1+y, duration=0.2)
can=True
c=None
mouse_move()
def left_click():
  """
  函数功能：鼠标左键点击
  """
  win32api.mouse_event(win32con.MOUSEEVENTF_LEFTDOWN | win32con.MOUSEEVENTF_LEFTUP, 0, 0, 0, 0)


def right_click():
  """
  函数功能：鼠标右键点击
  """
  win32api.mouse_event(win32con.MOUSEEVENTF_RIGHTDOWN | win32con.MOUSEEVENTF_RIGHTUP, 0, 0, 0, 0)


def left_down():
  """
  函数功能：鼠标左键按下
  """
  win32api.mouse_event(win32con.MOUSEEVENTF_LEFTDOWN, 0, 0, 0, 0)


def left_up():
  """
  函数功能：鼠标左键抬起
  """
  win32api.mouse_event(win32con.MOUSEEVENTF_LEFTUP, 0, 0, 0, 0)


def right_down():
  """
  函数功能：鼠标右键按下
  """
  win32api.mouse_event(win32con.MOUSEEVENTF_RIGHTDOWN, 0, 0, 0, 0)


def right_up():
  """
  函数功能：鼠标右键抬起
  """
  win32api.mouse_event(win32con.MOUSEEVENTF_RIGHTUP, 0, 0, 0, 0)
right=False
left=False
while run:
    #print(str(long)+"x"+str(high))
    #w1.geometry(str(long)+"x"+str(high)+"+200+100")
    #if w1.state()=="normal":#iconic":
    #print(w1.state())
    ret, img = cap.read()
    img = cv2.flip(img, 1)  # 因为摄像头是镜像的，所以需要将摄像头水平翻转
    hand,img = detector.findHands(img,flipType=False)
    # 存放手指点的信息和手的边界框信息
    #lmList, bboxInfo = detector.findPosition(img)
    # draw the visual keyboard
    img = drawAll_transparence(img, buttonList)
 
    if hand:
        lmList = hand[0]['lmList']
        #print(lmList[8])
        x1, y1 , none = lmList[8]
        x2, y2 , none= lmList[12]
        cc=False
        for button in buttonList:
            x, y = button.pos
            w, h = button.size
 
            if x <= x1 <= x + w and y <= y1 <= y + h:
                # 当食指的位置，在矩形框中，将矩形框的颜色变浅；文本字体变大
                cv2.rectangle(img, (x, y), (x + w, y + h), (255, 0, 255), cv2.FILLED)#矩形背景
                cvzone.cornerRect(img, (x, y, w, h), 20, rt=0, colorC=(0, 175, 0))#矩形边角
                cv2.putText(img, button.text, (x + 22, y + 65), cv2.FONT_HERSHEY_PLAIN, 4, (255, 255, 255), thickness=3)#输入的字母
 
                # when clicked
                len, _, img = detector.findDistance((x1,y1), (x2,y2), img)
                # 当食指与中指的距离小于50时，执行if语句中的操作
                if len < 50:
                    # 当食指与中指的距离小于50时，变换矩形框的颜色；文本字体变大
                    cv2.rectangle(img, (x, y), (x + w, y + h), (255, 0, 255), cv2.FILLED)
                    cvzone.cornerRect(img, (x, y, w, h), 20, rt=0, colorC=(255, 0, 0))
                    cv2.putText(img, button.text, (x + 22, y + 65), cv2.FONT_HERSHEY_PLAIN, 4, (255, 255, 255),thickness=3)
 
                    if button.text!=c:
                        #global cc,c
                        #print(button.text,c)
                        c=button.text
                        #global cc,c
                        cc=True
                        #print(button.text,c)
                        # 输出button.text的内容到finalText中
                        #if button.text == "del":
                        #    #finalText = finalText[0:-1]#删除最后的字符
                        #    k.tap_key(k.backspace_key)
                        #    num_text = num_text - 1
                        #if button.text == "Enter":
                        #    #finalText += (50 - num_text % 50) * " "#补充空格进行换行
                        #    k.press_key(k.enter_key)#k.type_string('\n')
                        #    for i in range(50 - num_text % 50):
                        #        num_text += 1
                        #if button.text != "del" and button.text != "Enter" and button.text != "                                                                          " and button.text != "?" and button.text != ";" and button.text != "," and button.text != "." and button.text != "/":
                        #    #finalText += button.text#添加字符
                        #    #k.type_string(button.text)
                        #    key_press(button.text)
                        #    num_text += 1
                        if button.text == " ":
                            pass
                            #k.type_string('?')
                        if button.text == "u":
                            mouse_move(y=-10)
                            num_text += 1
                            #k.type_string(';')
                            #num_text += 1
                        if button.text == "l":
                            mouse_move(x=-10)
                            pass
                            #k.type_string(';')
                            #num_text += 1
                        if button.text == "r":
                            mouse_move(x=10)
                            num_text += 1
                            pass
                            #finalText += ' '
                            #k.press_key(k.space)
                            #k.type_string(' ')
                            #num_text += 1
                        if button.text == "d":
                            mouse_move(y=10)
                            num_text += 1
                            pass
                            #k.type_string(",")
                            #num_text += 1
                        if button.text == "[":
                            left_click()
                            time.sleep(0.2)
                            num_text += 1
                            pass
                        if button.text == "]":
                            right_click()
                            time.sleep(0.2)
                            num_text += 1
                            pass
                        if button.text == '{':
                            #left=False
                            if left==False:
                                left_down()
                                left=True
                            elif left==True:
                                left_up()
                                left=False
                            #left_click()
                            time.sleep(0.2)
                            num_text += 1
                            pass
                        if button.text == '}':
                            #right=False
                            if right==False:
                                right_down()
                                right=True
                            elif right==True:
                                right_up()
                                right=False
                            #right_click()
                            time.sleep(0.2)
                            num_text += 1
                            pass
                    #time.sleep(0.2)  # 每次按键的间隔时间
            else:
                pass
                #if cc==1:
                #    #print(cc)
                #    c=None
                #    cc+=1
        if cc==False:
            c=None
        cc=False
        #cc=1
 
    # 显示字符；
    # 实现换行:当遇到Enter按键时,直接换行；每行满50个字符时，换行
    times = num_text // 50
    #cv2.rectangle(img, (80, 400), (1200, 450 + times * 25), (255, 0, 255), cv2.FILLED)
    for i in range(times + 1):
        cv2.putText(img, finalText[50 * i:50 * (i + 1)], (90, 425 + 25 * i), cv2.FONT_HERSHEY_PLAIN, 2, (255, 255, 255),thickness=2)
 
    # 显示一帧图像
    #cv2.resizeWindow("Image", 400,300)
    #cv2.namedWindow('Image',0)
    #cv2.imshow("Image", img)
    cv2.imwrite('.\photo.png', cv2.resize(img,(long,high),interpolation=cv2.INTER_CUBIC))
    #photo = tk.PhotoImage(file=".\phot.png")
    #imageLabel = tk.Label(imageLabel_win, image=photo)
    #imageLabel.pack(side=tk.LEFT)
    img1 = Image.open('.\photo.png')
    if ab==1:
        photo = ImageTk.PhotoImage(img1)
        #photo=Image.fromarray(photo).resize(400,300)
        image_Label = tkinter.Label(w1, image=photo)
        image_Label.pack(fill=tkinter.BOTH,expand=tkinter.YES)
    else:
        #photo = ImageTk.PhotoImage(img1)
        #image_Label.update()
        photo = ImageTk.PhotoImage(img1)
        #photo=Image.fromarray(photo).resize(400,300)
        image_Label['image']=photo
        image_Label.image=photo
        image_Label.update()
    #w.mainloop()　　
    ab+=1
    if cv2.waitKey(1) & 0xFF == ord('q'):  # q键退出
        break
cap.release()#停止捕获视频
#cv2.destroyAllWindows()#关闭所有显示窗口
