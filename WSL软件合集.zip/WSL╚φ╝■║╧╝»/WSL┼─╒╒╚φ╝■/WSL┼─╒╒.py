import cv2
import pygame
import pygame.display as dis
import pygame.image as img
import pygame.transform as tf
import time
import os
pygame.init()
def snapShotCt(name="图片",camera_idx = 1): # camera_idx的作用是选择摄像头。如果为0则使用内置摄像头，比如笔记本的摄像头，用1或其他的就是切换摄像头。
    cap = cv2.VideoCapture(camera_idx)
    ret, frame = cap.read() # cao.read()返回两个值，第一个存储一个bool值，表示拍摄成功与否。第二个是当前截取的图片帧。
    cv2.imwrite(name+".png", frame) # 写入图片
    cap.release() # 释放
    
#snapShotCt(input("name:"),0) # 运行
 
def snapShotCt1(name="图片",camera_idx = 1): # camera_idx的作用是选择摄像头。如果为0则使用内置摄像头，比如笔记本的摄像头，用1或其他的就是切换摄像头。
    cap = cv2.VideoCapture(camera_idx)
    ret, frame = cap.read() # cao.read()返回两个值，第一个存储一个bool值，表示拍摄成功与否。第二个是当前截取的图片帧。
    screen=dis.set_mode((600,400),flags=0,depth=0)
    dis.set_icon(img.load(r".\图标.png"))
    dis.set_caption("WSL拍照软件")
    photo_path=r"photo.png"
    number=1
    if os.path.isfile("照片储存区.txt"):#os.path.exists("照片储存区.txt"):
        file2 = open("照片储存区.txt",'w')
        file2.write(str(number))
        file2.close()
    try:
        f =open("照片储存区.txt","r")
        f.close()
    except FileNotFoundError:
        file2 = open("照片储存区.txt",'w')
        file2.write(str(number))
        file2.close()
    we=open("照片储存区.txt","r")
    number=int(we.read())
    we.close()
    rect1=pygame.Rect(520,180,70,70)#537,189
    while ret:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                os.remove(r".\photo.png")
                file2 = open("照片储存区.txt",'w+')
                file2.write(str(number))
                file2.close()
                exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                #print(str(x)+","+str(y))
                if (rect1.collidepoint(x,y)):
                    photo_path="photo_"+str(number)+".png"#r"photo.png"#'.\照片\'+
                    number+=1
                    print("拍摄成功")
                #print(x,y)
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    photo_path="photo_"+str(number)+".png"#r"photo.png"#'.\照片\'+
                    number+=1
                    print("拍摄成功")
                    #cv2.imwrite(str(time.time), frame)
            if event.type == pygame.MOUSEMOTION:
                #print(event, flag)
                x, y = event.pos
                #if rect2.collidepoint(a.x,a.y):
        #cv2.imwrite(name+".png", frame) # 写入图片
        cv2.imwrite(photo_path, frame)
        #time.sleep(1) # 休眠一秒 可通过这个设置拍摄间隔，类似帧。
        photo_path=r"photo.png"
        ret, frame = cap.read() # 下一个帧图片
        js=img.load(r"photo.png")#按钮.png
        js1=tf.scale(img.load(r".\按钮.png"),(70,70))#537,189
        screen.blit(js,(0,0))
        screen.blit(js1,rect1)
        #time.sleep(0.01)
        dis.update()
    cap.release()
try:	#写一个 try 把可能出错的代码放进去。
    pass
except Exception as e:# 写一个except
    pass
snapShotCt1("a",0)
